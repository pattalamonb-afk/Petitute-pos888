# Petitute POS (มีจำกัดจำนวนห้อง S/M/L + กันซ้อนจอง) - พร้อม Deploy

ฟีเจอร์:
- ฝากค้างคืน (S/M/L) + ฝากรายชั่วโมง (นับโควตาตาม S/M/L เหมือนกัน)
- อาบน้ำ/กรูมมิ่ง (ไม่ใช้โควตาห้อง)
- สมาชิก (ลด 10% + แต้ม)
- ล็อกอินแอดมิน
- ป้องกันการจองเกินจำนวนห้อง (เช็กช่วงเวลาเหลื่อมกัน)

ค่าดีฟอลต์จำนวนห้อง (แก้ได้ผ่าน Environment Variables):
- CAP_S = 2
- CAP_M = 2
- CAP_L = 1

## Deploy บน Render (เชื่อม GitHub หรือ Manual หากมี)
- Environment: Python
- Build: `pip install -r requirements.txt`
- Start: `gunicorn app:app`
- Plan: Free

เพิ่ม Environment Variables:
- SECRET_KEY = สุ่มสตริง
- ADMIN_USER = admin
- ADMIN_PASS = ตั้งรหัสปลอดภัย
- CAP_S = 2
- CAP_M = 2
- CAP_L = 1

หลัง deploy เสร็จ เปิด Shell แล้วรัน: `python db_init.py`
